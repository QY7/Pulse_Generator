/*
 * APWM_utils.h
 *
 *  Created on: May 20, 2021
 *      Author: Felix
 */

#ifndef APWM_UTILS_H_
#define APWM_UTILS_H_


void enableAPWMGPIO();
void disableAPWMGPIO();

#endif /* APWM_UTILS_H_ */
