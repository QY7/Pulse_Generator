/*
 * global_funcs.c
 *
 *  Created on: May 20, 2021
 *      Author: Felix
 */




