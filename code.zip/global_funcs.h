/*
 * global_funcs.h
 *
 *  Created on: May 20, 2021
 *      Author: Felix
 */

#ifndef GLOBAL_FUNCS_H_
#define GLOBAL_FUNCS_H_

extern inline void delay_us(unsigned int delay);



#endif /* GLOBAL_FUNCS_H_ */
