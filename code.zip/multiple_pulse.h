/*
 * multiple_pulse.h
 *
 *  Created on: May 20, 2021
 *      Author: Felix
 */

#ifndef MULTIPLE_PULSE_H_
#define MULTIPLE_PULSE_H_

void init_operation(OPERATION op[]);
void single_pulse_start();

#endif /* MULTIPLE_PULSE_H_ */
